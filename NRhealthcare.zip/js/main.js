
$(document).ready(()=>{
    $('.menu-btn').click(()=>{
        $('.nav').toggleClass('nav-expand')
    })
})