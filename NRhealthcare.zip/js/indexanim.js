gsap.from('header',{duration:1, y:'-100%',ease:'bounce'})
// gsap.from('.link',{duration:1,opacity:0,delay:1,stagger:.2})

const menu_btn = document.querySelector('.menu-btn')
