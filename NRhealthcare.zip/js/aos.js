document.querySelector('.container')
    .addEventListener('scroll', () => {
        AOS.refresh()
    })
AOS.init()